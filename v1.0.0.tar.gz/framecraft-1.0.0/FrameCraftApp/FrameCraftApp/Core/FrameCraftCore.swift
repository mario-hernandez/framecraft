// FrameCraftCore
// Framework compartido para generación de frames de App Store

// Re-export all public types
@_exported import struct Foundation.URL
@_exported import class Foundation.FileManager
